【滋賀大学 学生支援LINEボット - セットアップ手順】

1. .env.example をコピーして .env を作成し、各トークンとAPIキーを入力
2. ターミナルで `npm install` を実行
3. `npm start` でローカル動作確認
4. Renderなどのホスティングにデプロイし、Webhook URLをLINE Developersに設定

質問があれば、チャットで聞いてください！